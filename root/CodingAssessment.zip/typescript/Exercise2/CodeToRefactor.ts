namespace Review 
{
    /**
     * Represents a person with a name and date of birth.
     */
    export class People {
        public name: string;
        public dob: Date;

        /**
         * Creates a new Person
         * @param name - Name of the person
         * @param dob - Optional date of birth. Defaults to under 16 years old if not provided
         */
        constructor(name: string, dob?: Date) {
            this.name = name;
            this.dob = dob ?? People.getUnder16Date();
        }

        /**
         * Name getter
         */
        get Name() {
            return this.name;
        }

        /**
         * DOB getter
         */
        get DOB() {
            return this.dob;
        }

        /**
         * getUnder16Date
         * returns the latest DOB for those under 16 years old.
         * Uses calendar years, cater leap years.
         * @returns Date object representing DOB for under 16 years old.
         */
        private static getUnder16Date(): Date {
            return new Date(new Date().setFullYear(new Date().getFullYear() - 15));
        }
    }

    /**
     * BirthingUnit manages a collection of People.
     * Provides methods to generate people, filter Bobs, and handle marriage name concatenation.
     */
    export class BirthingUnit 
    {
        /** Internal array of People */
        private people: Review.People[];

        constructor() {
            this.people = [];
        }

        /**
         * GetPeople
         * Generates a number of random People.
         * Names are either "Bob" or "Betty".
         * Ages range between 18 and 85 years.
         *
         * @param count Number of people to generate
         * @returns Array of People (internal collection)
         */
        public GetPeople(count: number): Review.People[] 
        {
            for (let i = 0; i < count; i++) {
                const name = Math.random() < 0.5 ? "Bob" : "Betty";

                const age = Math.floor(Math.random() * (85 - 18 + 1)) + 18;

                const dob = new Date();
                dob.setFullYear(dob.getFullYear() - age);

                this.people.push(new Review.People(name, dob));
            }

            return this.people;
        }

        /**
         * GetBobs
         * Returns all Bobs.
         * If olderThan30 is true, returns only Bobs aged 30 or older.
         *
         * @param olderThan30 Whether to filter by age > 30
         * @returns Filtered array of People
         */
        public GetBobs(olderThan30: boolean): Review.People[] {
            const now = new Date();

            return this.people.filter(person => {
                if (person.Name !== "Bob") return false;

                if (!olderThan30) return true;

                const age = now.getFullYear() - person.DOB.getFullYear();
                return age > 30;
            });
        }

        /**
         * GetMarried
         * Concatenates first and last name.
         * If lastName contains "test", return first name only.
         * If full name exceeds 255 characters, truncate.
         * @param people Person
         * @param lastName Last name
         * @returns Full name
         */
        public GetMarried(people: Review.People, lastName: string): string {
            if (lastName.includes("test")) {
                return people.Name;
            }

            let fullName = `${people.Name} ${lastName}`;
            if (fullName.length > 255) {
                fullName = fullName.substring(0, 255);
            }

            return fullName;
        }
    }
}

/** 
 * Expose globally for Jest / CommonJS environment 
 * Keeps legacy code working in browser and provides global access in tests.
 */
if (typeof globalThis !== "undefined") {
    (globalThis as any).Review = Review;
}