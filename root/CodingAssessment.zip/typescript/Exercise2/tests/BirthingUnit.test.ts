import "../CodeToRefactor";

describe('BirthingUnit', () => {

  let unit: Review.BirthingUnit;

  beforeEach(() => {
    unit = new Review.BirthingUnit();
  });

  /**
   * GetPeople()
   */
  test('Given count_When GetPeople called_Then _people has i new entries', () => {
    const arrPeople = unit.GetPeople(2);
    expect(arrPeople.length).toBeGreaterThanOrEqual(2);
  });

  test('Given count_When GetPeople called_Then each generated person has Name Bob or Betty', () => {
    const arrPeople = unit.GetPeople(3);
    arrPeople.forEach(people => {
      expect(['Bob', 'Betty']).toContain(people.Name);
    });
  });

  test('Given count_When GetPeople called_Then each generated person has DOB between 18-85 years of age', () => {
    const arrPeople = unit.GetPeople(4);
    const now = new Date();

    arrPeople.forEach(people => {
      const age = now.getFullYear() - people.DOB.getFullYear();

      expect(age).toBeGreaterThanOrEqual(18);
      expect(age).toBeLessThanOrEqual(85);
    });
  });

  /**
   * GetBobs()
   */
  test('Given olderThan30 as false_When GetBobs called_Then return all Bobs', () => {
    unit.GetPeople(5);
    const bobs: Review.People[] = (unit as any).GetBobs(false);
    bobs.forEach(people => expect(people.Name).toBe('Bob'));
  });

  test('Given olderThan30 as true_When GetBobs called_Then return all Bobs older than 30', () => {
    unit.GetPeople(5);
    const olderBobs: Review.People[] = (unit as any).GetBobs(true);
    olderBobs.forEach((people: Review.People) => {
      expect(people.Name).toBe('Bob');
      // Legacy code may incorrectly include younger Bobs due to date comparison bug
      const age = new Date().getFullYear() - people.DOB.getFullYear();
      expect(age).toBeGreaterThan(30);
    });
  });

  /**
   * GetMarried()
   */
  test('Given people and lastName_When GetMarried called_Then returns concatenated name correctly', () => {
    const people = new Review.People('Donna');
    const fullName = unit.GetMarried(people, 'Astucia');
    expect(fullName).toBe('Donna Astucia');
  });

  test('Given people and lastName_When GetMarried called_Then returns a truncated names exceeding 255 characters', () => {
    const people = new Review.People('D'.repeat(200));
    const lastName = 'A'.repeat(200);

    const fullName = unit.GetMarried(people, lastName);
    expect(fullName.length).toBeLessThanOrEqual(255);
  });

  test('Given people and lastName_When GetMarried called_Then returns only Name if lastName includes "test"', () => {
    const people = new Review.People('Donna');
    const fullName = unit.GetMarried(people, 'test');
    expect(fullName).toBe('Donna');
  });
});