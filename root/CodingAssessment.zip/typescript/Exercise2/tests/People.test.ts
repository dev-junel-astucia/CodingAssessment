
import "../CodeToRefactor";

describe('People', () => {
  test('Given name only_When constructing_Then name is assigned', () => {
    const person = new Review.People('Jun');

    expect(person.Name).toBe('Jun');
  });

  test('Given name only_When constructing_Then DOB should defaults to Under16', () => {
    const person = new Review.People('Jun');

    expect(person.DOB).toBeDefined();
  });

  test('Given name only_When constructing_Then DOB should be 15 years ago', () => {
    const person = new Review.People('Jun');

    const now = new Date();
    const age = now.getFullYear() - person.DOB.getFullYear();
    expect(age).toBeLessThan(16);
  });

  test('Given name and DOB_When constructing_Then DOB is assigned correctly', () => {
    const dob = new Date(1988, 1, 1);
    const person = new Review.People('Jun', dob);

    expect(person.DOB).toEqual(dob);
  });
});