export enum Color {
  Hearts = "HEARTS",
  Diamonds = "DIAMONDS",
  Clubs = "CLUBS",
  Spades = "SPADES"
}