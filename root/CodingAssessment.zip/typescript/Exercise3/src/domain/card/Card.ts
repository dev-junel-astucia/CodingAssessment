import { Color } from "./Color";
import { Value } from "./Value";

export class Card {
  constructor(
    public readonly color: Color,
    public readonly value: Value
  ) {}

  toString(): string {
    return `${this.color}-${this.value}`;
  }
}