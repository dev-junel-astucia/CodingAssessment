export class Computer {
  name: string;

  constructor(name: string) {
    this.name = name;
  }
}