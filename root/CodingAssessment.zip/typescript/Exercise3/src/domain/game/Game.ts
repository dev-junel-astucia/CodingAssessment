import { Deck } from "../deck/Deck";
import { Player } from "./Player";
import { Computer } from "./Computer";
import { Card } from "../card/Card";
import { Value } from "../card/Value";
import { Shuffler } from "../deck/Shuffler";

const ValueRank: Record<Value, number> = {
  [Value.Two]: 2,
  [Value.Three]: 3,
  [Value.Four]: 4,
  [Value.Five]: 5,
  [Value.Six]: 6,
  [Value.Seven]: 7,
  [Value.Eight]: 8,
  [Value.Nine]: 9,
  [Value.Ten]: 10,
  [Value.Jack]: 11,
  [Value.Queen]: 12,
  [Value.King]: 13,
  [Value.Ace]: 14,
};

type RoundLog = {
  playerCard: Card;
  computerCard: Card;
  winner: string;
};

export class Game {
  private deck: Deck;
  private player: Player;
  private computer: Computer;
  private shuffler: Shuffler;
  private playerScore: number = 0;
  private computerScore: number = 0;

  constructor(deck: Deck, shuffler: Shuffler, player: Player, computer: Computer) {
    this.deck = deck;
    this.player = player;
    this.computer = computer;
    this.shuffler = shuffler;

    this.deck.shuffle(this.shuffler);
  }

  playRound(): RoundLog {
    const playerCard = this.deck.draw() as Card;
    const computerCard = this.deck.draw() as Card;

    const winner = this.determineWinner(playerCard, computerCard);

    // Update scores
    if (winner === this.player.name) {
      this.playerScore++;
    } else {
      this.computerScore++;
    }
    
    return { playerCard, computerCard, winner };
  }

  playStart(): string {
    while (this.deck.size() > 0) {
      this.playRound();
    }

    if (this.playerScore === this.computerScore) return "TIE";

    return this.playerScore > this.computerScore ? this.player.name : this.computer.name;
  }

  playStartWithOutput(): RoundLog[] {
    const logs: RoundLog[] = [];

    while (this.deck.size() > 0) {
      const roundLog = this.playRound();
      logs.push(roundLog);
    }

    return logs;
  }

  getScores() {
    return {
      [this.player.name]: this.playerScore,
      [this.computer.name]: this.computerScore,
    };
  }

  private determineWinner(playerCard: Card, computerCard: Card): string {
    const playerValue = ValueRank[playerCard.value];
    const computerValue = ValueRank[computerCard.value];

    if (playerValue === computerValue) {
      return Math.random() < 0.5
        ? this.player.name
        : this.computer.name;
    }

    return playerValue > computerValue
      ? this.player.name
      : this.computer.name;
  }
}