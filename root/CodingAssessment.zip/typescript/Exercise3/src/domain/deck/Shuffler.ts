export interface Shuffler {
  shuffle<T>(cards: T[]): T[];
}