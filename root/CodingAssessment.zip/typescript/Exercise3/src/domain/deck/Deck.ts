import { Card } from "../card/Card";
import { Color } from "../card/Color";
import { Value } from "../card/Value";
import { Shuffler } from "./Shuffler";

export class Deck {
  private cards: Card[];

  constructor(cards: Card[] = []) {
    this.cards = [...cards];
  }

  size(): number {
    return this.cards.length;
  }

  getCards(): Card[] {
    return [...this.cards];
  }

  shuffle(shuffler: Shuffler): void {
    this.cards = shuffler.shuffle(this.cards);
  }

  draw(): Card;
  draw(count: number): Card[];
  draw(count?: number): Card | Card[] {
    if (!count || count === 1) {
      return this.cards.shift()!;
    }

    const hand: Card[] = [];
    for (let i = 0; i < count; i++) {
      hand.push(this.cards.shift()!);
    }
    return hand;
  }

  static build(): Deck {
    const cards: Card[] = [];
    const colors = [Color.Hearts, Color.Diamonds, Color.Clubs, Color.Spades];
    const values = [
      Value.Ace, Value.Two, Value.Three, Value.Four, Value.Five, Value.Six,
      Value.Seven, Value.Eight, Value.Nine, Value.Ten, Value.Jack, Value.Queen, Value.King
    ];

    for (const color of colors) {
      for (const value of values) {
        cards.push(new Card(color, value));
      }
    }

    return new Deck(cards);
  }
}