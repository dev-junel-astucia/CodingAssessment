import { describe, it, expect } from "vitest";
import { Deck } from "../../../src/domain/deck/Deck";
import { Card } from "../../../src/domain/card/Card";
import { Color } from "../../../src/domain/card/Color";
import { Value } from "../../../src/domain/card/Value";

describe("Deck", () => {
  it("Given new Deck_When created_Then size is 0", () => {
    const deck = new Deck();
    const size = deck.size();
    expect(size).toBe(0);
  });

  it("Given Deck with cards_When created_Then size matches the number of cards", () => {
    const cards = [
      new Card(Color.Hearts, Value.Ace),
      new Card(Color.Spades, Value.Ten),
    ];

    const deck = new Deck(cards);
    const size = deck.size();

    expect(size).toBe(2);
  });
});