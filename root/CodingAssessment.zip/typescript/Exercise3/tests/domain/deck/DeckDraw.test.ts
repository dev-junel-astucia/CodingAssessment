import { describe, it, expect } from "vitest";
import { Deck } from "../../../src/domain/deck/Deck";
import { Card } from "../../../src/domain/card/Card";
import { Color } from "../../../src/domain/card/Color";
import { Value } from "../../../src/domain/card/Value";

describe("Deck Draw", () => {
  it("Given Deck with cards_When draw_Then card will removed and return the deck", () => {
    const cards = [
      new Card(Color.Hearts, Value.Ace),
      new Card(Color.Spades, Value.Ten),
    ];
    const deck = new Deck(cards);

    const drawn = deck.draw();

    expect(drawn).toBe(cards[0]); // draws first card
    expect(deck.size()).toBe(1);   // size reduced
    expect(deck.getCards()).toEqual([cards[1]]);
  });

  it("Given Deck with cards_When draw multiple_Then cards will removed and return the deck", () => {
    const deck = Deck.build();

    const hand = deck.draw(5); // refactored to cater multiple count draw

    expect(hand).toHaveLength(5);
    expect(deck.size()).toBe(47);
    expect(hand[0]).toEqual(new Card(Color.Hearts, Value.Ace));
  });
});