import { describe, it, expect } from "vitest";
import { Deck } from "../../../src/domain/deck/Deck";
import { Card } from "../../../src/domain/card/Card";
import { Color } from "../../../src/domain/card/Color";
import { Value } from "../../../src/domain/card/Value";
import { Shuffler } from "../../../src/domain/deck/Shuffler";

// Dummy shuffler for test
class DummyShuffler implements Shuffler {
  shuffle(cards: Card[]): Card[] {
    // Dummy shuffle behavior
    return [...cards].reverse();
  }
}

describe("Deck Shuffle", () => {
  it("Given Deck with cards_When shuffled_Then order changes", () => {
    const cards = [
      new Card(Color.Hearts, Value.Ace),
      new Card(Color.Spades, Value.Ten),
      new Card(Color.Diamonds, Value.King),
    ];

    const deck = new Deck(cards);

    const shuffler = new DummyShuffler();
    deck.shuffle(shuffler);

    const shuffledOrder = deck.getCards();
    expect(shuffledOrder).not.toEqual(cards);
  });
});