import { describe, it, expect } from "vitest";
import { Deck } from "../../../src/domain/deck/Deck";
import { Card } from "../../../src/domain/card/Card";
import { Color } from "../../../src/domain/card/Color";
import { Value } from "../../../src/domain/card/Value";

describe("Deck Builder", () => {
  it("Given empty Deck_When build_Then_Deck contains 52 Cards", () => {
    const deck = Deck.build();

    expect(deck.size()).toBe(52);

    const cards = deck.getCards();

    expect(cards[0]).toEqual(new Card(Color.Hearts, Value.Ace));
    expect(cards[51]).toEqual(new Card(Color.Spades, Value.King));
  });
});