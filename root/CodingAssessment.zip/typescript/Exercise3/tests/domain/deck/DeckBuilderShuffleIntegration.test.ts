import { describe, it, expect } from "vitest";
import { Deck } from "../../../src/domain/deck/Deck";
import { Card } from "../../../src/domain/card/Card";
import { Color } from "../../../src/domain/card/Color";
import { Value } from "../../../src/domain/card/Value";
import { Shuffler } from "../../../src/domain/deck/Shuffler";

// Dummy shuffler for test
class DummyShuffler implements Shuffler {
  shuffle(cards: Card[]): Card[] {
    // Dummy shuffle behavior
    return [...cards].reverse();
  }
}

describe("Deck Builder and Shuffle Integration", () => {
  it("Given Deck with cards_When build and shuffle is called_Then cards order changed", () => {
    const deck = Deck.build();
    const shuffler = new DummyShuffler();

    deck.shuffle(shuffler);

    const cards = deck.getCards();
    // First card should now be the previous last card
    expect(cards[0]).toEqual(new Card(Color.Spades, Value.King));
    expect(cards[51]).toEqual(new Card(Color.Hearts, Value.Ace));
  });
});