import { describe, it, expect } from "vitest";
import { Deck } from "../../../src/domain/deck/Deck";
import { BasicShuffler } from "../../../src/infrastructure/BasicShuffler";
import { Player } from "../../../src/domain/game/Player";
import { Computer } from "../../../src/domain/game/Computer";
import { Game } from "../../../src/domain/game/Game";

describe("Game Output", () => {
  it("Given Deck_When playStartWithOutput Called_Then round logs are returned", () => {
    const deck = Deck.build();
    const shuffler = new BasicShuffler();
    const player = new Player("Jun");
    const computer = new Computer("CPU");

    const game = new Game(deck, shuffler, player, computer);

    const logs = game.playStartWithOutput();

    expect(Array.isArray(logs)).toBe(true);
    expect(logs.length).toBeGreaterThan(0);
    expect(logs[0]).toHaveProperty("playerCard");
    expect(logs[0]).toHaveProperty("computerCard");
    expect(logs[0]).toHaveProperty("winner");
  });
});