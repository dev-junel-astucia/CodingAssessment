import { describe, it, expect } from "vitest";
import { Deck } from "../../../src/domain/deck/Deck";
import { BasicShuffler } from "../../../src/infrastructure/BasicShuffler";
import { Player } from "../../../src/domain/game/Player";
import { Computer } from "../../../src/domain/game/Computer";
import { Game } from "../../../src/domain/game/Game";

describe("Game", () => {
  it("Given Deck_When Game called playRound_Then there will be a winner", () => {
    const deck = Deck.build();
    const shuffler = new BasicShuffler();
    const player = new Player("Jun");
    const computer = new Computer("CPU");

    const game = new Game(deck, shuffler, player, computer);

    const roundLog = game.playRound();

    expect(["Jun", "CPU"]).toContain(roundLog.winner);
  });

  it("Given Deck_When Game called playStart_Then overall winner returned", () => {
    const deck = Deck.build();
    const shuffler = new BasicShuffler();
    const player = new Player("Jun");
    const computer = new Computer("CPU");

    const game = new Game(deck, shuffler, player, computer);

    const winner = game.playStart();

    expect(["Jun", "CPU", "TIE"]).toContain(winner);
  });
});