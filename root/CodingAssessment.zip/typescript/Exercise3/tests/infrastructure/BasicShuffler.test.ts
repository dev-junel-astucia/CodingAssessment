import { describe, it, expect } from "vitest";
import { Deck } from "../../src/domain/deck/Deck";
import { Color } from "../../src/domain/card/Color";
import { Value } from "../../src/domain/card/Value";
import { BasicShuffler } from "../../src/infrastructure/BasicShuffler";

describe("Basic Shuffler", () => {
  it("Given Deck_When shuffle called_Then cards order changes", () => {
    const deck = Deck.build();
    const shuffler = new BasicShuffler();

    const originalOrder = deck.getCards();

    deck.shuffle(shuffler);
    const shuffledOrder = deck.getCards();

    // Expect shuffled order to be different from the original order
    expect(shuffledOrder).not.toEqual(originalOrder);
    // Expect same cards order when sort
    expect(shuffledOrder.sort()).toEqual(originalOrder.sort());
  });
});