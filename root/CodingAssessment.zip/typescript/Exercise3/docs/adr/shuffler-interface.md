# ADR: Introduce Shuffler Interface to Decouple Deck from Implementation

## Status
Accepted

## Context / Problem
Originally, the `Deck` class had hardcoded shuffle behavior using `BasicShuffler`.  
This tightly couples domain logic to a specific infrastructure implementation, making testing difficult and violating Clean Architecture principles.

## Decision
- Deck and Game now depend only on this interface
- BasicShuffler in infrastructure implements this interface
- Tests inject BasicShuffler to validate behavior
- Any future shuffler can be swapped without modifying domain

## Alternatives Considered
1. **Keep Deck coupled to BasicShuffler**  
   - Pros: simpler  
   - Cons: tight coupling, less testable

2. **Pass a shuffle function directly**  
   - Pros: lightweight  
   - Cons: loses explicit domain modeling, harder to enforce type safety

## What We Learned
- Domain no longer depends on infrastructure  
- Shuffle logic is pluggable  
- Tests are easier to manage  
- Initially seemed overkill, but clarified responsibilities