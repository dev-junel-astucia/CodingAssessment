# Exercise 3 — Clean Green Fields Project (Card Game)

> **As** an enthusiastic card player and developer
> **I want to** create a program to play cards against the computer
> **So that** when I am bored I can play against an intelligent opponent.

## Overview

Design and implement a clean card game program using **TypeScript** 

- Player vs Computer mode
- Core functionality includes Deck, Cards and Ability to Shuffle
- Demonstrate clean architecture
- Is built using Test-Driven Development (TDD)

## Constraints

- UI decision will come later.
- Gameplay is unknown.
- Must demonstrate clean architecture
- Must demonstrate TDD.
- Must include delivery pipeline.

## Assumptions

- Node.js runtime
- Using standard Playing Card Deck
- Computer must have the ability to decide the best move (possibility of using AI in the future)

## Architectural Overview (Clean Architecture)

- Domain layer
- Application layer
- Infrastructure layer
- Delivery layer (interfaces)

## Development Approach

- Test-Driven Development
